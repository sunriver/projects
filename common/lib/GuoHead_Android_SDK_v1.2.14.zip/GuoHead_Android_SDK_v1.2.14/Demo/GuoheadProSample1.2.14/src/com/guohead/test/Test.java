package com.guohead.test;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;

import com.guohead.sdk.GHView;

public class Test extends Activity{

	private LayoutInflater mInflater;
	private View convertView;
	LinearLayout testid=null;
	private GHView ghView_2;
	private LinearLayout testid2;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main_test);
		testid=(LinearLayout)findViewById(R.id.testid);
		testid2=(LinearLayout)findViewById(R.id.testid2);


		//原生代码方式
		GHView  ghView_1=new GHView(this);
		testid.addView(ghView_1);
		ghView_1.setAdUnitId("284dd749187f55d26ae3e38a8e5fc991");
		ghView_1.startLoadAd();
		//setListener("自主广告", ghView_1);


		//从其他xml布局inflate的方式

		mInflater = LayoutInflater.from(this);
		convertView = mInflater.inflate(R.layout.test1, null);
		testid2.addView(convertView);
		ghView_2 = (GHView)convertView.findViewById(R.id.mGHView_test);
		ghView_2.setAdUnitId("4311b0f5b37a734839c4623be0011f76");
		//setListener("自主广告", ghView_1);
		ghView_2.startLoadAd();
	}

}
