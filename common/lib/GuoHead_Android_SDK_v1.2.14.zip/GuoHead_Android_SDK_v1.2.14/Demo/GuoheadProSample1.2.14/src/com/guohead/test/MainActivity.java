package com.guohead.test;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;

import com.guohead.sdk.GHView;
import com.guohead.sdk.GHView.OnAdClickedListener;
import com.guohead.sdk.GHView.OnAdClosedListener;
import com.guohead.sdk.GHView.OnAdFailedListener;
import com.guohead.sdk.GHView.OnAdLoadedListener;
import com.guohead.sdk.GHView.OnAdWillLoadListener;

public class MainActivity extends Activity {
	GHView ghView_1;
	GHView ghView_2;
	GHView ghView_3;
	private String tag="GH";
	Button bDemo;
	Button bUpdate;
	Button preloadBtn=null;

	Button startLoadAd=null;
	Button endLoadAd=null;

	ViewGroup vgDemo;
	ViewGroup vgUpdate;
	private Button moreBtn;
	

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		init();
	}

	// 初始化
	void init() {
		bDemo = (Button) findViewById(R.id.bDemo);
		bUpdate = (Button) findViewById(R.id.bUpdate);
		vgDemo = (ViewGroup) findViewById(R.id.vgDemo);
		vgUpdate = (ViewGroup) findViewById(R.id.vgUpdate);

		startLoadAd=(Button)findViewById(R.id.startloadadBtn1);
		endLoadAd=(Button)findViewById(R.id.endloadadBtn1);
		moreBtn=(Button)findViewById(R.id.more);
		preloadBtn = (Button) findViewById(R.id.preloadBtn);

		startLoadAd.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				if(ghView_3!=null){
					if(ghView_3.getVisibility()!=View.VISIBLE){
						ghView_3.setVisibility(View.VISIBLE);
					}
					ghView_3.restartLoadAd();
				}

			}
		});

		endLoadAd.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				if(ghView_3!=null)
					ghView_3.pauseLoadAd();
			}
		});

		moreBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {

				Intent i=new Intent();
				i.setClass(MainActivity.this, Test.class);
				startActivity(i);

			}
		});
		
		preloadBtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent i = new Intent();
				i.setClass(MainActivity.this, PreloadActivity.class);
				startActivity(i);
			}
		});

		bDemo.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				toDemoView();
			}
		});

		bUpdate.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				toUpdateView();
			}
		});
		toDemoView();
	}

	// 广告展示界面
	void toDemoView() {
		bUpdate.setBackgroundResource(R.drawable.btn_unselected);
		bDemo.setBackgroundResource(R.drawable.btn_selected);

		vgDemo.setVisibility(View.VISIBLE);
		vgUpdate.setVisibility(View.GONE);
		//正式
		if (ghView_1 == null) {
			ghView_1 = (GHView) findViewById(R.id.mGHView_1);
			ghView_1.setAdUnitId("284dd749187f55d26ae3e38a8e5fc991");
			setListener("自主广告", ghView_1);
			ghView_1.setKeywords("threekey");
			ghView_1.startLoadAd();
		}
		
		
		
		if (ghView_3 == null) {
			ghView_3 = (GHView) findViewById(R.id.mGHView_3);
			ghView_3.setAdUnitId("e117913fa9e077adb12f4b88a243efc9");
			setListener("平台广告", ghView_3);
			ghView_3.startLoadAd();
		}



	}

	// 更新历史界面
	void toUpdateView() {
		bUpdate.setBackgroundResource(R.drawable.btn_selected);
		bDemo.setBackgroundResource(R.drawable.btn_unselected);
		vgDemo.setVisibility(View.GONE);
		vgUpdate.setVisibility(View.VISIBLE);
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		ghView_1.destroy();
//		ghView_2.destroy();
		ghView_3.destroy();
	}

	// 监听广告状态（非必须）
	void setListener(final String name, GHView ghView) {
		// 监听广告展示前状态
		ghView.setOnAdWillLoadListener(new OnAdWillLoadListener() {


			@Override
			public void OnAdWillLoad(GHView ghView) {
				// TODO Auto-generated method stub
				Log.i(tag,name + " : OnAdWillLoad()");
			}
		});

		// 监听广告成功展示
		ghView.setOnAdLoadedListener(new OnAdLoadedListener() {
			@Override
			public void OnAdLoaded(GHView ghView) {
				// TODO Auto-generated method stub
				Log.i(tag,name + " : OnAdLoaded()");
			}

		});
		// 广告被点击时被调用
		ghView.setOnAdClickedListener(new OnAdClickedListener() {
			@Override
			public void OnAdClicked(GHView ghView) {
				// TODO Auto-generated method stub
				Log.i(tag,name + " : OnAdClicked()");
			}
		});
		// 广告请求失败时被调用
		ghView.setOnAdFailedListener(new OnAdFailedListener() {

			@Override
			public void OnAdFailed(GHView ghView) {
				// TODO Auto-generated method stub
				Log.i(tag,name + " : OnAdFailed()");
			}
		});
		// 广告页面关闭时被调用
		ghView.setOnAdClosedListener(new OnAdClosedListener() {

			@Override
			public void OnAdClosed(GHView ghView) {
				// TODO Auto-generated method stub
				Log.i(tag,name + " : OnAdClosed()");
			}
		});

	}

}