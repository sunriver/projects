package com.guohead.test;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

import com.guohead.sdk.GHView;
import com.guohead.test.R;
import com.guohead.sdk.GHView.OnAdClickedListener;
import com.guohead.sdk.GHView.OnAdClosedListener;
import com.guohead.sdk.GHView.OnAdFailedListener;
import com.guohead.sdk.GHView.OnAdLoadedListener;
import com.guohead.sdk.GHView.OnAdWillLoadListener;
import com.guohead.sdk.utils.Logger;

public class PreloadActivity extends Activity {
	private GHView ghViewPre = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.preload_view);
		ghViewPre = (GHView) findViewById(R.id.mGHView_pre);
		// 设置广告位ID信息
		ghViewPre.setAdUnitId("51f3b34ffebfd831cef57acf621c39a3");
		// 启动预加载功能，进行预加载该广告位内的全屏自主广告
		ghViewPre.preloadAd();
		setListener("预加载自主广告", ghViewPre);
		Button preLoadBtn = (Button) findViewById(R.id.showPreLoadAd);
		preLoadBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// getLoadReadyOrNot()返回值为true时，说明该广告位内的全屏自主广告预加载成功
				if (ghViewPre.getLoadReadyOrNot()) {
					// 显示广告位的广告，因为开启了预加载功能，所以该广告位内的全屏自主广告加载速度会有所提升
					ghViewPre.startLoadAd();
				} else {
				}

			}
		});
	}

	// 监听广告状态（非必须）
	void setListener(final String name, GHView ghView) {
		// 监听广告展示前状态
		ghView.setOnAdWillLoadListener(new OnAdWillLoadListener() {

			@Override
			public void OnAdWillLoad(GHView arg0) {
				// TODO Auto-generated method stub
				Logger.i(name + " : OnAdWillLoad()");
			}
		});

		// 监听广告成功展示
		ghView.setOnAdLoadedListener(new OnAdLoadedListener() {
			@Override
			public void OnAdLoaded(GHView arg0) {
				// TODO Auto-generated method stub
				Logger.i(name + " : OnAdLoaded()");
			}

		});
		// 广告被点击时被调用
		ghView.setOnAdClickedListener(new OnAdClickedListener() {
			@Override
			public void OnAdClicked(GHView arg0) {
				// TODO Auto-generated method stub
				Logger.i(name + " : OnAdClicked()");
			}
		});
		// 广告请求失败时被调用
		ghView.setOnAdFailedListener(new OnAdFailedListener() {

			@Override
			public void OnAdFailed(GHView arg0) {
				// TODO Auto-generated method stub
				Logger.i(name + " : OnAdFailed()");
			}
		});
		// 广告页面关闭时被调用
		ghView.setOnAdClosedListener(new OnAdClosedListener() {

			@Override
			public void OnAdClosed(GHView arg0) {
				// TODO Auto-generated method stub
				Logger.i(name + " : OnAdClosed()");
			}

		});

	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		if (ghViewPre != null) {
			ghViewPre.destroy();
		}
	}
}
