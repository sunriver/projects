package com.guohead.sdk.adapters;

import com.adchina.android.ads.AdEngine;
import com.adchina.android.ads.AdListener;
import com.adchina.android.ads.AdManager;
import com.adchina.android.ads.views.AdView;
import com.guohead.sdk.BaseAdapter;
import com.guohead.sdk.GHView;
import com.guohead.sdk.utils.Utils;

public class AdChinaAdapter extends BaseAdapter implements AdListener{

	private AdView mAdView;

	public AdChinaAdapter(GHView view, String params) {
		super(view, params, "adChina");
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onClick() {
		// TODO Auto-generated method stub

	}

	@Override
	public void loadAd() {
		// TODO Auto-generated method stub
		super.loadAd();
		if(mAdView == null)
			mAdView = new AdView(mGHView.getContext(), keys[0], true, false);
		else
			mAdView.start();
		AdEngine.setAdListener(this); 
		AdManager.setRefershinterval(-1);
		AdManager.setRelateScreenRotate(mGHView.getContext(), false);
		mAdView.setId(Utils.TYPE_ADCHINA);
		addView(mAdView);

	}



	@Override
	public void onRefreshAd(AdView arg0) {
		receiveAd(mAdView); 
	}
	@Override
	public void onFailedToRefreshAd(AdView arg0) {
		failedReceiveAd(mAdView); 

	}

	@Override
	public void onReceiveAd(AdView arg0) {
		receiveAd(mAdView); 

	}
	@Override
	public void onFailedToReceiveAd(AdView arg0) {
		failedReceiveAd(mAdView); 

	}
	@Override
	public boolean OnRecvSms(AdView arg0, String arg1) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public void onFailedToReceiveVideoAd() {
		// TODO Auto-generated method stub

	}
	@Override
	public void onDisplayFullScreenAd() {
		// TODO Auto-generated method stub

	}


	@Override
	public void onReceiveVideoAd() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onFailedToPlayVideoAd() {
		// TODO Auto-generated method stub

	}



	@Override
	public void onFailedToReceiveFullScreenAd() {
		// TODO Auto-generated method stub

	}



	@Override
	public void onPlayVideoAd() {
		// TODO Auto-generated method stub

	}



	@Override
	public void onReceiveFullScreenAd() {
		// TODO Auto-generated method stub

	}


	@Override
	public void onEndFullScreenLandpage() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onStartFullScreenLandPage() {
		// TODO Auto-generated method stub
		
	}



}
