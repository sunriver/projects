package com.guohead.sdk.adapters;

import android.widget.RelativeLayout.LayoutParams;

import com.guohead.sdk.BaseAdapter;
import com.guohead.sdk.GHView;
import com.guohead.sdk.utils.Utils;
import com.wooboo.adlib_android.AdListener;
import com.wooboo.adlib_android.WoobooAdView;

public class WoobooAdapter extends BaseAdapter  implements AdListener {
	private WoobooAdView mAdView=null;
	public WoobooAdapter(GHView view, String params) {
		super(view, params, "wooboo");
		// TODO Auto-generated constructor stub
	}

	@Override
	public void loadAd() {
		// TODO Auto-generated method stub
		super.loadAd();
		boolean debug=false;
		try {
			debug=Boolean.parseBoolean(keys[1].trim());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mAdView = new  WoobooAdView(mGHView.getContext(), 
				keys[0], 0x3232, 
				0x9232, debug,
				600, null); 

		LayoutParams params = new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT);
		mAdView.setLayoutParams(params);
		mAdView.setId(Utils.TYPE_WOOBOO);
		mAdView.setAdListener(this);
		addView(mAdView);
	}

	@Override
	public void onClick() {

	}


	@Override
	public void onFailedToReceiveAd(Object arg0) {
		mAdView.setAdListener(null);
		failedReceiveAd(mAdView);
	}

	@Override
	public void onPlayFinish() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onReceiveAd(Object arg0) {
		mAdView.setAdListener(null);
		receiveAd(mAdView);

	}


}
