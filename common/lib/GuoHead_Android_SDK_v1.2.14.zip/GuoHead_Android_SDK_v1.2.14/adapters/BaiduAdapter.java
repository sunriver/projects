package com.guohead.sdk.adapters;

import android.view.Gravity;
import android.widget.LinearLayout;

import com.baidu.mobads.AdService;
import com.baidu.mobads.AdType;
import com.baidu.mobads.AdView;
import com.baidu.mobads.AdViewListener;
import com.guohead.sdk.BaseAdapter;
import com.guohead.sdk.GHView;
import com.guohead.sdk.utils.Logger;

public class BaiduAdapter extends BaseAdapter implements AdViewListener {
	private AdService adService;
	private AdView mAdView;

	public BaiduAdapter(GHView view, String params) {
		super(view, params, "baidu");
	}

	@Override
	public void loadAd() {
		super.loadAd();
		hasClickInterface = true;
		mGHView.removeAllViews();
		LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
				LinearLayout.LayoutParams.FILL_PARENT,
				LinearLayout.LayoutParams.WRAP_CONTENT);
		layoutParams.gravity = Gravity.CENTER;
		if (keys[0].trim().equals("1")) {
			adService = new AdService(mGHView.getContext(), AdType.IMAGE,
					mGHView, layoutParams, this);
		} else {
			adService = new AdService(mGHView.getContext(), AdType.TEXT,
					mGHView, layoutParams, this);
		}
	}

	@Override
	public void onAdClick() {
		mGHView.registerClick();
	}

	@Override
	public void onAdFailed(String arg0) {
		failedReceiveAd(mAdView);
	}

	@Override
	public void onAdReady() {
		try {
			mAdView = adService.requestAdView();

		} catch (Exception e) {
			Logger.e("an error occured while loading Baidu ad ");
			failedReceiveAd(mAdView);
		}
	}

	@Override
	public void onAdShow() {
		trackCacheImpression();
	}

	@Override
	public void onAdSwitch() {
		switchAd(mAdView);
		cacheImpressiomUrl();
		Logger.i("baidu   onAdSwitch......");
	}

	@Override
	public void onClick() {
		// TODO Auto-generated method stub

	}

}
