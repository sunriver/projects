/*
 * Copyright (c) 2011, GuoheAd Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in the
 *   documentation and/or other materials provided with the distribution.
 *
 * * Neither the name of 'GuoheAd Inc.' nor the names of its contributors
 *   may be used to endorse or promote products derived from this software
 *   without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package com.guohead.sdk.adapters;

import java.lang.ref.WeakReference;

import android.app.Activity;
import android.view.View;

import com.guohead.sdk.BaseAdapter;
import com.guohead.sdk.GHView;
import com.guohead.sdk.utils.Logger;
import com.guohead.sdk.utils.Utils;
import com.millennialmedia.android.MMAdView;
import com.millennialmedia.android.MMAdView.MMAdListener;
import com.millennialmedia.android.MMAdViewSDK;

public class MillennialAdapter extends BaseAdapter implements MMAdListener {

	private MMAdView mAdView;

//	private boolean mHasAlreadyRegisteredImpression;

	private WeakReference<Activity> mActivityReference;

	public MillennialAdapter(GHView view, String params) {
		super(view, params, "Millennial");
		this.mActivityReference = new WeakReference<Activity>(
				(Activity) view.getContext());
	}

	@Override
	public void loadAd() {
		Activity activity = mActivityReference.get();
		super.loadAd();
		String mmAdType = MMAdView.BANNER_AD_TOP;

		mAdView = new MMAdView(activity, keys[0], mmAdType,
				MMAdView.REFRESH_INTERVAL_OFF);
		mAdView.setId(MMAdViewSDK.DEFAULT_VIEWID);
		mAdView.setListener(this);
		mAdView.setVisibility(View.INVISIBLE);
//		mHasAlreadyRegisteredImpression = false;
		mAdView.setId(Utils.TYPE_MILLENNIAL);
		mAdView.callForAd();
		addView(mAdView);
	}

	@Override
	public void invalidate() {
		super.invalidate();
	}

	@Override
	public void MMAdFailed(MMAdView adview) {
		Logger.i("GH", "MMAdReturned ====>");
		mAdView.setListener(null);
		failedReceiveAd(mAdView);
	}

	@Override
	public void MMAdReturned(MMAdView adview) {
		Logger.i("GH", "MMAdReturned ====>");
		mAdView.setListener(null);
		receiveAd(mAdView);
		/*Activity activity = mActivityReference.get();
		if (activity != null && mGHView != null) {
			activity.runOnUiThread(new MMRunnable(mGHView, adview));
		}*/
	}

	@Override
	public void MMAdClickedToNewBrowser(MMAdView adview) {
	}

	@Override
	public void MMAdClickedToOverlay(MMAdView adview) {
	}

	@Override
	public void MMAdOverlayLaunched(MMAdView adview) {
		// Nothing needs to happen.
	}

	@Override
	public void MMAdRequestIsCaching(MMAdView adview) {
		// Nothing needs to happen.
	}
/*
	private class MMRunnable implements Runnable {
		private GHAdView mGHView;
		private MMAdView mMMAdView;

		public MMRunnable(GHAdView view, MMAdView adView) {
			mGHView = view;
			mMMAdView = adView;
		}

		public void run() {
			if (mGHView != null && mMMAdView != null) {
				mGHView.removeAllViews();
				mMMAdView.setVisibility(View.VISIBLE);
				mMMAdView.setHorizontalScrollBarEnabled(false);
				mMMAdView.setVerticalScrollBarEnabled(false);
				FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(
						FrameLayout.LayoutParams.FILL_PARENT,
						FrameLayout.LayoutParams.FILL_PARENT);
				layoutParams.gravity = Gravity.CENTER_HORIZONTAL
						| Gravity.CENTER_VERTICAL;
				mGHView.addView(mMMAdView, layoutParams);
				mGHView.nativeAdLoaded();
				if (!mHasAlreadyRegisteredImpression) {
					mHasAlreadyRegisteredImpression = true;
					mGHView.trackNativeImpression();
				}
			}
		}
	}*/

	 
	@Override
	public void onClick() {
		// should do nothing
	}

	@Override
	public void MMAdCachingCompleted(MMAdView arg0, boolean arg1) {
		// TODO Auto-generated method stub
		
	}

}