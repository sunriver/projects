package com.guohead.sdk.adapters;

import android.graphics.Color;

import com.fractalist.sdk.ad.FtadSdk;
import com.fractalist.sdk.ad.FtadStatusListener;
import com.fractalist.sdk.ad.data.FtadReceiveState;
import com.fractalist.sdk.ad.data.FtadShowState;
import com.fractalist.sdk.ad.manager.FtadManager;
import com.fractalist.sdk.ad.view.FtadBannerView;
import com.guohead.sdk.BaseAdapter;
import com.guohead.sdk.GHView;
import com.guohead.sdk.utils.Logger;

public class AdmarketAdapter extends BaseAdapter implements FtadStatusListener {
	private FtadBannerView mAdView;
	private FtadManager manager;

	public AdmarketAdapter(GHView view, String params) {
		super(view, params, "Ftad");

	}

	@Override
	public void loadAd() {
		super.loadAd();

		if (manager != null && mAdView != null) {
			manager.removeFtadNeeder(mAdView);
		} else {
			manager = new FtadManager(mGHView.getContext());
		}
		mAdView = new FtadBannerView(mGHView.getContext());
		mAdView.setShowCloseButton(false);
		mAdView.setBackgroundColor(Color.TRANSPARENT);
		mAdView.setAdIdentify("banner");
		// FtadManager manager = new FtadManager(mGHView.getContext());
		manager.addFtadNeeder(mAdView);
		manager.setPublisherId(keys[0]);
		manager.setDownloadInterval(0);
		manager.start();
		FtadSdk.addFtadStatusListener(this);
		addView(mAdView);
	}

	@Override
	public void invalidate() {
		super.invalidate();
	}

	@Override
	public void onClick() {

	}

	@Override
	public void onAdClosed(String arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onAdFullScreenClose(String arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onAdFullScreenShow(String arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onClick(String arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onReceiveAdFailad(String arg0, FtadReceiveState arg1) {
		failedReceiveAd(mAdView);

	}

	@Override
	public void onReceiveAdSuccess(String arg0) {
		Logger.i("ftad   onReceivedFreshAd......");
		receiveAd(mAdView);

	}

	@Override
	public void onShowAdFailed(String arg0, FtadShowState arg1) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onShowAdSuccess(String arg0) {
		// TODO Auto-generated method stub

	}

}
