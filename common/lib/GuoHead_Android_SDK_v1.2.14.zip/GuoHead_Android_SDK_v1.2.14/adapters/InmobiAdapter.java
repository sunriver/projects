package com.guohead.sdk.adapters;

import com.guohead.sdk.BaseAdapter;
import com.guohead.sdk.GHView;
import com.guohead.sdk.utils.Logger;
import com.guohead.sdk.utils.Utils;
import com.inmobi.androidsdk.IMAdListener;
import com.inmobi.androidsdk.IMAdRequest;
import com.inmobi.androidsdk.IMAdRequest.ErrorCode;
import com.inmobi.androidsdk.IMAdView;

public class InmobiAdapter extends BaseAdapter implements IMAdListener {

	private IMAdView mAdView;

	public InmobiAdapter(GHView view, String params) {
		super(view, params, "Inmobi");
		// TODO Auto-generated constructor stub
	}

	@Override
	public void loadAd() {
		// TODO Auto-generated method stub
		super.loadAd();
		//		if (mAdView == null) {
		if(mAdView!=null){
			mAdView=null;
		}
		mAdView = new IMAdView(mGHView.getActivity(),
				IMAdView.INMOBI_AD_UNIT_320X50, keys[0]);
		boolean debug =false;
		try {
			debug=Boolean.parseBoolean(keys[1]);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			debug =false;
		}
		IMAdRequest adRequest = new IMAdRequest();
		adRequest.setTestMode(debug);
		mAdView.setIMAdRequest(adRequest);
		mAdView.setId(Utils.TYPE_INMOBI);
		mAdView.setIMAdListener(this);
		//		}
		addView(mAdView);
	}

	@Override
	public void invalidate() {
		super.invalidate();
	}

	@Override
	public void onClick() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onAdRequestCompleted(IMAdView adView) {
		// TODO Auto-generated method stub
		Logger.i("InMobiAdapter-> onAdRequestCompleted, adView: " + adView);
		mAdView.setIMAdListener(null);
		receiveAd(mAdView);

	}

	@Override
	public void onAdRequestFailed(IMAdView adView, ErrorCode errorCode) {
		// TODO Auto-generated method stub
		Logger.e("InMobiAdapter-> onAdRequestFailed, adView: " + adView
				+ " ,errorCode: " + errorCode);
		mAdView.setIMAdListener(null);
		failedReceiveAd(mAdView);
	}

	@Override
	public void onDismissAdScreen(IMAdView adView) {
		// TODO Auto-generated method stub
		Logger.i("InMobiAdapter-> onDismissAdScreen, adView: " + adView);

	}

	@Override
	public void onShowAdScreen(IMAdView adView) {
		// TODO Auto-generated method stub
		Logger.i("InMobiAdapter-> onShowAdScreen, adView: " + adView);
	}

}
