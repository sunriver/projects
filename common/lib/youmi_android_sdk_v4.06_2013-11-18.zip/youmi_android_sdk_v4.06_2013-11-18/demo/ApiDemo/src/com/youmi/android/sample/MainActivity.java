package com.youmi.android.sample;

import net.youmi.android.AdManager;
import net.youmi.android.dev.AppUpdateInfo;
import net.youmi.android.dev.CheckAppUpdateCallBack;
import net.youmi.android.offers.OffersManager;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener {



	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		// 初始化接口，应用启动的时候调用
		// 参数：appId, appSecret, 调试模式
		AdManager.getInstance(this).init("73057fb81878f2ba",
				"f2707618edb7c2a4", false);
		// 如果使用积分广告，请务必调用积分广告的初始化接口:
		OffersManager.getInstance(this).onAppLaunch();
		// demo按钮点击事件绑定
		findViewById(R.id.toAdActivity).setOnClickListener(this); // 无积分广告demo导航
		findViewById(R.id.toOffersActivity).setOnClickListener(this); // 有积分广告demo导航
		findViewById(R.id.updateApp).setOnClickListener(this);		
	}
	

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		// 如果使用积分广告，请务必调用积分广告的初始化接口:
		OffersManager.getInstance(this).onAppExit();
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub

		switch (v.getId()) {
		case R.id.toAdActivity:
			// 导航到传统无积分广告demo
			startActivity(new Intent(this, AdDemo.class));
			break;
		case R.id.toOffersActivity:
			// 导航到积分广告demo
			startActivity(new Intent(this, OffersDemo.class));
			break;
		case R.id.updateApp:
			// 检查更新
			checkAppUpdate();
		default:
			break;
		}
	}

	private void checkAppUpdate() {
		AdManager.getInstance(MainActivity.this).asyncCheckAppUpdate(
				new CheckAppUpdateCallBack() {

					@Override
					public void onCheckAppUpdateFinish(
							AppUpdateInfo appUpdateInfo) {
						if (appUpdateInfo == null) {
							Toast.makeText(MainActivity.this, "当前版本已经是最新版",
									Toast.LENGTH_SHORT).show();
						} else {
							// 获取版本号
							int versionCode = appUpdateInfo.getVersionCode();
							// 获取版本
							String versionName = appUpdateInfo.getVersionName();
							// 获取新版本的信息
							String updateTips = appUpdateInfo.getUpdateTips();
							// 获取apk下载地址
							final String downloadUrl = appUpdateInfo.getUrl();

							AlertDialog updateDialog = new AlertDialog.Builder(
									MainActivity.this)
									.setIcon(android.R.drawable.ic_dialog_info)
									.setTitle("发现新版本 " + versionName)
									.setMessage(updateTips)
									.setPositiveButton(
											"更新",
											new DialogInterface.OnClickListener() {
												@Override
												public void onClick(
														DialogInterface dialog,
														int which) {
													try {
														Intent intent = Intent
																.parseUri(
																		downloadUrl,
																		Intent.FLAG_ACTIVITY_NEW_TASK);
														startActivity(intent);
													} catch (Exception e) {
														// TODO: handle
														// exception
													}
												}
											}).setNegativeButton("下次再说", null)
									.create();
							updateDialog.show();
						}
					}
				});
	}

	

}
