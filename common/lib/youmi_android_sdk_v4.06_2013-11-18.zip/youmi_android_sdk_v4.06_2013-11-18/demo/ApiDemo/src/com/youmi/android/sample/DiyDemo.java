package com.youmi.android.sample;

import java.util.List;

import net.youmi.android.diy.AdObject;
import net.youmi.android.diy.DiyManager;
import net.youmi.android.diy.banner.DiyAdSize;
import net.youmi.android.diy.banner.DiyBanner;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;

/**
 * Created by mosida on 13-7-12.
 */
public class DiyDemo extends Activity {

    Button showSourceWallBtn;
    Button showRecommendWallBtn;
    List<AdObject> adList;

    @SuppressWarnings("unchecked")
    public void onCreate(Bundle bundle){
        super.onCreate(bundle);
        setContentView(R.layout.activity_diydemo);


        // Mini广告
        ((RelativeLayout)findViewById(R.id.adLayout)).addView(new DiyBanner(this, DiyAdSize.SIZE_MATCH_SCREENx32));

        showRecommendWallBtn = (Button) findViewById(R.id.showRecommendWall);
        showRecommendWallBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 展示所有应用推荐墙
                DiyManager.showRecommendWall(DiyDemo.this);
                // 展示应用推荐墙
                // DiyManager.showRecommendAppWall(DiyDemo.this);
                // 展示游戏推荐墙
                // DiyManager.showRecommendGameWall(DiyDemo.this);
            }
        });


    }
}
