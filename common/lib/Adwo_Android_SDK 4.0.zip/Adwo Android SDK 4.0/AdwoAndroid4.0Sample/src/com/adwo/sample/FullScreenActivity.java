package com.adwo.sample;

import com.adwo.adsdk.AdDisplayer;
import com.adwo.adsdk.ErrorCode;
import com.adwo.adsdk.FullScreenAdListener;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Window;
import android.widget.RelativeLayout;

/**
 * @author ADWO 此实例为adwo全屏广告展示。
 *         adwo全屏为了能使广告更快，更好的展示，采用了外部存储卡存储机制。所有的广告资源都存放在手机外部存储卡的adwo目录下。
 *         adwo全屏广告从请求到销毁完全按照Android程序构架机制设计
 *         。有初始化，设置参数，请求，加载，请求加载成功失败回调接口，展示和销毁等接口。
 *         请在manifest里面设置当前activity属性     android:configChanges="keyboard|keyboardHidden|orientation|screenSize"
 */
public class FullScreenActivity extends Activity implements FullScreenAdListener {
	
	private String LOG_TAG = "Adwo";
	private RelativeLayout layout;
	private static AdDisplayer displayer;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);

		setContentView(R.layout.activity_show);
		
		Log.e(LOG_TAG, "onCreate");

	}
	
	@Override
	protected void onStart() {
		super.onStart();
		layout = (RelativeLayout) findViewById(R.id.layout);
		Intent intent = getIntent();
		int fsForm = intent.getIntExtra("form", 0);
		Log.e(LOG_TAG, "fsForm->"+fsForm);
		
//		请在manifest里面设置当前activity属性     android:configChanges="keyboard|keyboardHidden|orientation|screenSize"
		// // 全屏广告实例
		displayer = AdDisplayer.getInstance(FullScreenActivity.this);
		// 初始化全屏广告参数
		displayer.initParems("2b8dbd92edd74a97b3ba6b0189bef125",true, FullScreenActivity.this);
		// 设置全屏格式
		/* 
		 * 可选参数有：AdDisplayer.ADWO_FS_INTERCEPT 插屏全屏
		 *         AdDisplayer.ADWO_FS_ENTRY
		 *         AdDisplayer.ADWO_FS_TRANSPOSITION
		 */
//		displayer.setDesireAdForm(AdDisplayer.ADWO_FS_INTERCEPT);
		displayer.setDesireAdForm((byte)fsForm);
		// 设置请求广告类型 可选。
		displayer.setDesireAdType(AdDisplayer.ADWO_FS_TYPE_APP_FUN);
		// 开始请求全屏广告
		displayer.requestFullScreenAd();
		
	}
	@Override
	public void onReceiveAd() {
		Log.e(LOG_TAG, "onReceiveAd");
		// 接收到全屏广告。加载全屏广告并展示
		displayer.preLoadFullScreenAd();
	}

	@Override
	public void onLoadAdComplete() {
		Log.e(LOG_TAG, "onLoadAdComplete");
		// 成功完成下载后，展示广告
		layout = (RelativeLayout) findViewById(R.id.layout);
		displayer.displayFullScreenAd(layout);
	}

	@Override
	public void onFailedToReceiveAd(ErrorCode errorCode) {
		Log.e(LOG_TAG, "onFailedToReceiveAd");
		if (errorCode.getErrorCode() == 36) {
			// 下载广告资源失败，此次广告无法显示
			Log.e(LOG_TAG, "onFailedToReceiveAd downloading resources failed.");
		}

	}

	@Override
	public void onAdDismiss() {
		//TODO 广告关闭回调接口
		Log.e(LOG_TAG, "onAdDismiss");
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		Log.e(LOG_TAG, "onDestroy");
		// 请在这里释放全屏广告资源
		if (displayer != null) {
			displayer.dismissDisplayer();
			displayer = null;
		}
	}
}
