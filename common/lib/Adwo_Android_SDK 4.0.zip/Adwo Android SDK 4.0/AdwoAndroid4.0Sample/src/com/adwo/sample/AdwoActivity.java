package com.adwo.sample;

import com.adwo.adsdk.AdListener;
import com.adwo.adsdk.AdwoAdView;
import com.adwo.adsdk.ErrorCode;

import android.app.Activity;
import android.os.Bundle;

import android.util.Log;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;

/**
 *  ADWO 此实例是adwo广告条展示 adwo广告全部默认宽都是和设备宽相等，也可以自行设置广告条的宽和高。
 *  adwo广告条添加嵌入遵循代码嵌入简单，广告大小适宜，广告资源消耗小等原则。
 */
public class AdwoActivity extends Activity implements AdListener {
	public static RelativeLayout layout;
	static AdwoAdView adView = null;
	String Adwo_PID = "2b8dbd92edd74a97b3ba6b0189bef125";
	LayoutParams params = null;
	private String LOG_TAG = "Adwo";

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.main);
		layout = (RelativeLayout) findViewById(R.id.layout);

		params = new LayoutParams(LayoutParams.WRAP_CONTENT,
				LayoutParams.WRAP_CONTENT);
//		当不设置广告条充满屏幕宽时建议放置在父容器中间。
		params.addRule(RelativeLayout.CENTER_HORIZONTAL);
		
//		
		Log.e(LOG_TAG, "requestAd");
//		adwo广告条的宽高默认是320*50乘以屏幕密度，默认宽是不充满屏宽，如果您想设置设置广告条宽充满屏幕宽您可以在实例化广告对象之前调用AdwoAdView.setBannerMatchScreenWidth(true)，
//		设置广告条充满屏幕宽
		AdwoAdView.setBannerMatchScreenWidth(true);
		// 实例化广告对象
		adView = new AdwoAdView(AdwoActivity.this, Adwo_PID,false, 40);
		// 设置广告监听回调
		adView.setListener(AdwoActivity.this);
		// 把广告条加入界面布局
		layout.addView(adView, params);

	}

	@Override
	public void onReceiveAd(AdwoAdView adView) {
		//TODO 接收到广告
		Log.e(LOG_TAG, "onReceiveAd");
	}

	@Override
	public void onFailedToReceiveAd(AdwoAdView adView, ErrorCode errorCode) {
		//TODO 接收到广告失败
		Log.e(LOG_TAG, "onFailedToReceiveAd");
	}

}
