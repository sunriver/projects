package com.adwo.sample;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

/**
 * Adwo 广告demo
 */
public class EntryActivity extends Activity {
	private Button bannerButton;
	private Button interceptButton;
	private Button entryButton;
	private Button transpositionButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setContentView(R.layout.entry);
        bannerButton = (Button) findViewById(R.id.bannerButton);
        interceptButton = (Button) findViewById(R.id.interceptButton);
        entryButton = (Button) findViewById(R.id.entryButton);
        transpositionButton = (Button) findViewById(R.id.transpositionButton);
        
        bannerButton.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				Intent intent = new Intent();
				intent.setClassName(EntryActivity.this, "com.adwo.sample.AdwoActivity");
				startActivity(intent);
		}});
        interceptButton.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				Intent intent = new Intent();
				intent.putExtra("form", 0);
				intent.setClassName(EntryActivity.this, "com.adwo.sample.FullScreenActivity");
				startActivity(intent);
		}});
        entryButton.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				Intent intent = new Intent();
				intent.putExtra("form", 1);
				intent.setClassName(EntryActivity.this, "com.adwo.sample.FullScreenActivity");
				startActivity(intent);
		}});
        transpositionButton.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v) {
				Intent intent = new Intent();
				intent.putExtra("form", 2);
				intent.setClassName(EntryActivity.this, "com.adwo.sample.FullScreenActivity");
				startActivity(intent);
		}});
    }
}


